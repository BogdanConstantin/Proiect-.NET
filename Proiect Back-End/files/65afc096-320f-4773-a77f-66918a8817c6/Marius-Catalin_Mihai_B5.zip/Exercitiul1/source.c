#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <time.h>
#include <stdlib.h>

typedef struct algorithm_params{
    unsigned char* key;
    unsigned char* iv;
    unsigned int encrypt;
    const EVP_CIPHER *cipher_type;
}algorithm_params;

#define DICTIONARY_LINE_COUNT 25143
#define BUFFER_LENGTH 10

void file_encrypt_decrypt(algorithm_params *params, FILE* input, FILE* output);

char* get_line_from_file(int line_number, char* file_name)
{
	FILE* f_dictionary = fopen(file_name,"rb");
	char* line = (char*)malloc(32);

	do
	{
		if (fgets(line,32,f_dictionary) == NULL)
			printf("Error at %d\n", line_number);
		line_number--;
	}while(line_number >= 0);
	
	fclose(f_dictionary);
	line[strlen(line)-1]='\0';
	return line;
}

// ads spaces to the key until it is 16 characters long
void add_spaces(char* key)
{
	for(int i=strlen(key); i<16; i++)
		key[i] = ' ';
	key[16] = '\0';
}

// converts the string to hex
char* convert_to_hex(char* plaintext_key)
{
	char* key = (char*)malloc(33);

	for(int i=0; i<strlen(plaintext_key);i++)
		sprintf(key+i*2,"%02X", plaintext_key[i]);

	free(plaintext_key);
	return key;
}

char* choose_random_key_from_dic()
{
	srand(time(NULL));

	int line_number = rand()%DICTIONARY_LINE_COUNT;
	char* key = get_line_from_file(line_number,"word_dict.txt");

	add_spaces(key);

	return key;
}

// generates a algorithm_params structure depending on the operation (encrypt/decrypt) and the type (ECB/OFB)
algorithm_params* generate_params(char* type, char* operation)
{
    algorithm_params *params = (algorithm_params *)malloc(sizeof(algorithm_params));

    unsigned char* iv = "\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f";

    if (strcmp(operation,"encrypt") == 0)
	{
		params->key = choose_random_key_from_dic();
		params->encrypt = 1;
	}    
	else if (strcmp(operation,"decrypt") == 0)
		params->encrypt = 0;

    if (strcmp(type,"OFB")==0)
    {
		params->iv = iv;
        params->cipher_type = EVP_aes_128_ofb();
    }
    else if (strcmp(type,"ECB")==0)
    {
		params->iv = NULL;	
        params->cipher_type = EVP_aes_128_ecb();
    }
}

void cleanup(algorithm_params* params, FILE* input, FILE* output, int error_code)
{
    printf("Error code: %d\n",error_code);
    fclose(output);
    fclose(input);
    exit(-1);
}

// creates the encrypted file criptotext
void create_ecrypted_file(char* argv[])
{
	FILE *f_input, *f_encrypted;

	algorithm_params *params = generate_params(argv[3],"encrypt");

    f_input = fopen(argv[1], "rb");
    if (!f_input) {
        fprintf(stderr, "ERROR: fopen error: %s\n", strerror(errno));
        exit(-1);
    }

    f_encrypted = fopen(argv[2], "wb");
    if (!f_encrypted) {
        fprintf(stderr, "ERROR: fopen error: %s\n", strerror(errno));
        exit(-1);
    }

	printf("Encrypting with key '%s'\n", params->key);
    file_encrypt_decrypt(params, f_input, f_encrypted);

    fclose(f_input);
    fclose(f_encrypted);

	free(params);

	printf("Created encrypted file\n");
}

// checks if the files have the same content
int identical_files(char* file1, char* file2)
{
	FILE* f1 = fopen(file1,"rb");
	FILE* f2 = fopen(file2,"rb");
	
	if (!f1) {
        fprintf(stderr, "ERROR: fopen error opening %s: %s\n", file1, strerror(errno));
        exit(errno);
    }

	if (!f2) {
        fprintf(stderr, "ERROR: fopen error opening %s: %s\n", file2, strerror(errno));
        exit(errno);
    }

	char str1[100], str2[100];
	char* result1;
	char* result2;

	do
	{
		result1 = fgets(str1, 100, f1);
		result2 = fgets(str2, 100, f2);

		if (strcmp(str1, str2) != 0)
		{
			fclose(f1);
			fclose(f2);
			return 0;
		}	
	}while(result1 != NULL && result2 != NULL);

	fclose(f1);
	fclose(f2);
	return 1;
}

// iterates through the words in the dictionary and creates a key out of each
// decrypts the criptotext with each key generated until the decrypted text equals the plaintext
void find_key(char* argv[])
{
    FILE *f_encrypted, *f_decrypted;
	algorithm_params *params = generate_params(argv[3],"decrypt");
	params->key = (char*) malloc(16);
	FILE* f_dictionar = fopen("word_dict.txt", "rb");
	char* key = (char*)malloc(32);

	int counter=1;

	while(fgets(key,32,f_dictionar) != NULL)
	{
		key[strlen(key)-1] = '\0';
		add_spaces(key);

		strcpy(params->key,key);

		counter++;
		
		f_decrypted = fopen("aux_file.txt", "wb");
		if (!f_decrypted) {
		    fprintf(stderr, "ERROR3: fopen error: %s\n", strerror(errno));
		    exit(errno);
		}

		f_encrypted = fopen(argv[2], "rb");
    	if (!f_encrypted) {
        	fprintf(stderr, "ERROR2: fopen error: %s\n", strerror(errno));
        	exit(errno);
    	}

		file_encrypt_decrypt(params, f_encrypted, f_decrypted);

    	fclose(f_decrypted);
    	fclose(f_encrypted);

		if(identical_files(argv[1], "aux_file.txt"))
		{
			printf("Found key in %d iterations! Key: '%s'\n", counter, key);
			break; 
		}
	}

	free(key);
    free(params);
}

int main(int argc, char *argv[]) {

    if (argc != 4) {
        printf("Numar incorect de parametri!\n");
        return -1;
    }

	if(access(argv[2], F_OK ) == -1 )
		create_ecrypted_file(argv);

	find_key(argv);

    return 0;
}

// encrypts or decrypts the file depending on the params values
void file_encrypt_decrypt(algorithm_params* params, FILE* input, FILE* output)
{
    unsigned char in_buffer[BUFFER_LENGTH], out_buffer[BUFFER_LENGTH + EVP_CIPHER_block_size(params->cipher_type)];
    int num_bytes_read, out_len;
    EVP_CIPHER_CTX *ctx;

    ctx = EVP_CIPHER_CTX_new();
    EVP_CipherInit_ex(ctx, params->cipher_type, NULL, NULL, NULL, params->encrypt);

    OPENSSL_assert(EVP_CIPHER_CTX_key_length(ctx) == 16);

    if (params->cipher_type == EVP_aes_128_ofb())
        OPENSSL_assert(EVP_CIPHER_CTX_iv_length(ctx) == 16);
	
    EVP_CipherInit_ex(ctx, NULL, NULL, params->key, params->iv, params->encrypt);

    do{
        num_bytes_read = fread(in_buffer, sizeof(unsigned char), BUFFER_LENGTH, input);

        EVP_CipherUpdate(ctx, out_buffer, &out_len, in_buffer, num_bytes_read);
        fwrite(out_buffer, sizeof(unsigned char), out_len, output);

    }while(num_bytes_read == BUFFER_LENGTH);

    EVP_CipherFinal_ex(ctx, out_buffer, &out_len);
    fwrite(out_buffer, sizeof(unsigned char), out_len, output);

    EVP_CIPHER_CTX_cleanup(ctx);
}
