#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <time.h>
#include <stdlib.h>

#define BUFFER_LENGTH 100

void generate_hash(int file_number, char* argv[], const EVP_MD* type)
{
	int num_bytes_read, result_length = EVP_MD_size(type);
	char buffer[BUFFER_LENGTH];
	FILE* input = fopen(argv[file_number],"rb");
	FILE* output;


	if(input == NULL)
	{
		printf("Error opening %s!\n", argv[file_number]);
		exit(1);
	}
	
	char* aux = malloc(result_length);
	char* hash = malloc(result_length*2);
	EVP_MD_CTX* ctx = EVP_MD_CTX_create();

	EVP_DigestInit_ex(ctx, type, NULL);

	do{
        num_bytes_read = fread(buffer, sizeof(unsigned char), BUFFER_LENGTH, input);
		EVP_DigestUpdate(ctx, buffer, num_bytes_read);
    }while(num_bytes_read == BUFFER_LENGTH);

	EVP_DigestFinal_ex(ctx, aux, NULL);
	EVP_MD_CTX_destroy(ctx);

	for(int i = 0; i < strlen(aux); i++)
   	  sprintf(hash + 2*i, "%02x", (unsigned int)aux[i] & 0xff);

	char output_name[16];

	if (file_number == 1)
		strcpy(output_name,"hash1");
	else
		strcpy(output_name,"hash2");

	if (type == EVP_md5())
		strcat(output_name,"_md5");
	else
		strcat(output_name,"_sha256");

	output = fopen(output_name, "wb");
    fwrite(hash, sizeof(unsigned char), strlen(hash), output);

	printf("%s: %s\n", output_name, hash);

	fclose(input);
	fclose(output);
	free(aux);
	free(hash);
}

void compare_files(char* file_name1, char* file_name2)
{
	FILE* file1 = fopen(file_name1,"rb");
	FILE* file2 = fopen(file_name2,"rb");

	int equal_bytes=0;
	char buffer1;
	char buffer2;

	while(fread(&buffer1, sizeof(unsigned char), 1, file1) != 0 && fread(&buffer2, sizeof(unsigned char), 1, file2) != 0)
		if (buffer1 == buffer2)
			equal_bytes++;
	
	printf("There are %d bytes equal between %s and %s!\n", equal_bytes, file_name1, file_name2);

	fclose(file1);
	fclose(file2);
}

int main(int argc, char* argv[])
{
	if (argc != 3)
	{
		printf("Incorrect number of arguments!\n");
		return 0;
	}
	else
	{
		generate_hash(1, argv, EVP_md5());
		generate_hash(2, argv, EVP_md5());
		printf("\n");
		generate_hash(1, argv, EVP_sha256());
		generate_hash(2, argv, EVP_sha256());
		printf("\n");
		compare_files("hash1_md5","hash2_md5");
		compare_files("hash1_sha256","hash2_sha256");
	}
}
